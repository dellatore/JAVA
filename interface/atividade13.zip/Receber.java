
package Atividade13;


public interface Receber {
    
    public String descricao();
   
    public double valorAReceber();
    
    
}
