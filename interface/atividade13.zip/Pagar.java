
package Atividade13;

public interface Pagar {
    
    public String getDescricao();
    
    public double getValorAPagar();
    
}
