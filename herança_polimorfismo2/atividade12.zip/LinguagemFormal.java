
package Atividade12;

public class LinguagemFormal {
 
    public void mostrarIdioma(){
        System.out.println("o idioma pertence a linguagem formal, correspondente as linguagens de produção");
    }
}
