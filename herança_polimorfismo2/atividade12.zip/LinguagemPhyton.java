
package Atividade12;

public class LinguagemPhyton extends LinguagemFormal{
    
    @Override
    public void mostrarIdioma(){
        super.mostrarIdioma();
        System.out.println(" essa é a linguagem com o maior numero de usuarios na area de computacao ");
        
    }
}
